import { type ReactNode, useEffect, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, SignIn, SignUp, useAuth, useClerk } from '@clerk/react';
import { dark } from '@clerk/themes';
import { publishableKeyFromHost } from '@clerk/react/internal';
import {
  AlertTriangle,
  ArrowDownToLine,
  Boxes,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleHelp,
  CloudUpload,
  Database,
  Download,
  FileArchive,
  FileCode2,
  FileText,
  HardDrive,
  HeartPulse,
  KeyRound,
  LockKeyhole,
  LogIn,
  Menu,
  Network,
  PackageOpen,
  Plus,
  RefreshCw,
  RotateCcw,
  Server,
  Settings2,
  Shield,
  ShieldCheck,
  Sparkles,
  Trash2,
  UploadCloud,
  UserRound,
  Wrench,
  X,
  Zap,
} from 'lucide-react';
import {
  getGetDashboardQueryKey,
  getGetSettingsQueryKey,
  getListActivityQueryKey,
  getListNodesQueryKey,
  getListObjectsQueryKey,
  getListRecoveryJobsQueryKey,
  getDownloadObjectQueryKey,
  useCorruptReplica,
  useDeleteObject,
  useDownloadObject,
  useFailNode,
  useGetDashboard,
  useGetSettings,
  useListActivity,
  useListNodes,
  useListObjects,
  useListRecoveryJobs,
  useRepairObject,
  useReplaceNode,
  useResetVault,
  useRestoreNode,
  useUpdateSettings,
  useUploadObject,
  useVerifyObject,
} from '@workspace/api-client-react';
import type {
  ActivityEvent,
  Dashboard,
  RecoveryJob,
  StorageNode,
  VaultObject,
  VaultSettings,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import NotFound from '@/pages/not-found';
import { Redirect, Route, Switch, Link, Router as WouterRouter, useLocation } from 'wouter';
import './index.css';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const clerkAppearance = {
  baseTheme: dark,
  variables: {
    colorPrimary: '#31d6ff',
    colorForeground: '#eef8ff',
    colorMutedForeground: '#91a6c4',
    colorBackground: '#09162d',
    colorInput: '#0c1d38',
    colorInputForeground: '#eef8ff',
    colorDanger: '#fb7185',
    colorNeutral: '#29466d',
    fontFamily: 'Manrope, sans-serif',
    borderRadius: '0.75rem',
  },
  elements: {
    card: 'border border-cyan-200/15 bg-[#09162d]/95 shadow-[0_0_60px_rgba(35,210,255,.12)]',
    headerTitle: 'text-slate-50',
    headerSubtitle: 'text-slate-400',
    formFieldLabel: 'text-slate-300',
    formFieldInput: 'border-cyan-100/10 bg-[#0c1d38] text-slate-100',
    formButtonPrimary: 'bg-cyan-300 text-[#07101f] hover:bg-cyan-200',
    footerActionLink: 'text-cyan-300 hover:text-cyan-200',
    footerActionText: 'text-slate-500',
    dividerText: 'text-slate-600',
    socialButtonsBlockButton: 'border-white/10 bg-white/[.03] text-slate-200 hover:bg-white/[.06]',
  },
};

const cn = (...classes: Array<string | false | undefined>) => classes.filter(Boolean).join(' ');
const formatBytes = (bytes = 0) => {
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / Math.pow(1024, index)).toFixed(index === 0 ? 0 : 1)} ${units[index]}`;
};
const formatDate = (date?: string) => date ? new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(date)) : '—';
const shortHash = (value?: string) => value ? `${value.slice(0, 10)}…${value.slice(-6)}` : '—';
const errorText = (error: unknown) => error instanceof Error ? error.message : 'The operation could not be completed.';

function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3" data-testid="brand-vault">
      <div className="relative grid h-9 w-9 place-items-center">
        <div className="absolute inset-0 rotate-45 rounded-[9px] border border-cyan-300/80 bg-cyan-300/10" />
        <div className="absolute inset-[6px] rotate-45 rounded-[5px] border border-violet-400/80" />
        <ShieldCheck className="relative h-5 w-5 text-cyan-300" strokeWidth={1.7} />
      </div>
      {!compact && <div>
        <div className="font-mono text-[17px] font-medium tracking-[0.28em] text-slate-100">VAULT</div>
        <div className="mt-0.5 text-[8px] tracking-[0.3em] text-cyan-300/70">STORE · PROTECT · RECOVER</div>
      </div>}
    </div>
  );
}

function Button({ children, className, variant = 'primary', ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'quiet' | 'danger' }) {
  return <button {...props} className={cn(
    'inline-flex items-center justify-center gap-2 rounded-lg px-3.5 py-2 text-[12px] font-semibold transition duration-200 disabled:cursor-not-allowed disabled:opacity-45',
    variant === 'primary' && 'bg-cyan-300 text-[#07101f] shadow-[0_0_20px_rgba(35,210,255,.16)] hover:bg-cyan-200',
    variant === 'secondary' && 'border border-cyan-300/30 bg-cyan-300/[.07] text-cyan-100 hover:bg-cyan-300/[.13]',
    variant === 'quiet' && 'text-slate-400 hover:bg-white/[.05] hover:text-slate-100',
    variant === 'danger' && 'border border-rose-400/25 bg-rose-400/[.08] text-rose-200 hover:bg-rose-400/[.15]',
    className,
  )} />;
}

function StatusPill({ status }: { status: string }) {
  const normalized = status.toLowerCase();
  const healthy = ['healthy', 'online', 'completed'].includes(normalized);
  const warning = ['under-replicated', 'repairing', 'pending', 'running'].includes(normalized);
  return <span className={cn(
    'inline-flex items-center gap-1.5 rounded-full border px-2 py-1 text-[10px] font-semibold uppercase tracking-[.12em]',
    healthy && 'border-emerald-300/20 bg-emerald-300/[.08] text-emerald-300',
    warning && 'border-amber-300/20 bg-amber-300/[.08] text-amber-200',
    !healthy && !warning && 'border-rose-300/20 bg-rose-300/[.08] text-rose-200',
  )} data-testid={`status-${normalized}`}>
    <span className={cn('h-1.5 w-1.5 rounded-full', healthy ? 'bg-emerald-300' : warning ? 'bg-amber-300' : 'bg-rose-300')} />
    {status.replace('-', ' ')}
  </span>;
}

function Skeleton({ className = '' }: { className?: string }) {
  return <div className={cn('animate-pulse rounded-md bg-white/[.06]', className)} aria-label="Loading" data-testid="loading-skeleton" />;
}

function EmptyState({ icon: Icon = PackageOpen, title, detail, action }: { icon?: typeof PackageOpen; title: string; detail: string; action?: ReactNode }) {
  return <div className="flex min-h-[240px] flex-col items-center justify-center rounded-xl border border-dashed border-cyan-200/15 bg-[#0a1730]/45 p-8 text-center" data-testid="empty-state">
    <div className="mb-4 grid h-12 w-12 place-items-center rounded-xl border border-cyan-300/20 bg-cyan-300/[.06] text-cyan-300"><Icon className="h-5 w-5" /></div>
    <h3 className="text-sm font-semibold text-slate-100">{title}</h3>
    <p className="mt-2 max-w-sm text-xs leading-5 text-slate-400">{detail}</p>
    {action && <div className="mt-5">{action}</div>}
  </div>;
}

function ErrorState({ message, retry }: { message: string; retry: () => void }) {
  return <div className="flex min-h-[180px] flex-col items-center justify-center rounded-xl border border-rose-300/20 bg-rose-400/[.04] p-6 text-center" data-testid="error-state">
    <AlertTriangle className="h-6 w-6 text-rose-300" />
    <p className="mt-3 text-sm text-rose-100">{message}</p>
    <Button className="mt-4" variant="danger" onClick={retry} data-testid="button-retry">Retry connection</Button>
  </div>;
}

function AppShell({ children }: { children: ReactNode }) {
  const { signOut } = useClerk();
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const nav = [
    { href: '/dashboard', label: 'Overview', icon: Boxes },
    { href: '/files', label: 'Object inventory', icon: Database },
    { href: '/nodes', label: 'Storage nodes', icon: Network },
    { href: '/settings', label: 'Settings', icon: Settings2 },
  ];
  return <div className="noise min-h-[100dvh] bg-[#07101f] text-slate-100">
    <div className="pointer-events-none fixed inset-0 overflow-hidden">
      <div className="absolute -right-48 -top-48 h-[32rem] w-[32rem] rounded-full bg-cyan-400/[.04] blur-3xl" />
      <div className="absolute -bottom-64 left-1/3 h-[30rem] w-[30rem] rounded-full bg-violet-500/[.04] blur-3xl" />
    </div>
    <aside className={cn('fixed inset-y-0 left-0 z-40 flex w-[246px] flex-col border-r border-cyan-100/10 bg-[#081427]/95 px-4 py-6 backdrop-blur-xl transition-transform md:translate-x-0', mobileOpen ? 'translate-x-0' : '-translate-x-full')}>
      <Link href="/" className="mb-10 px-3" onClick={() => setMobileOpen(false)}><BrandMark /></Link>
      <div className="mb-3 px-3 font-mono text-[10px] uppercase tracking-[.2em] text-slate-500">Control plane</div>
      <nav className="space-y-1">
        {nav.map(({ href, label, icon: Icon }) => <Link key={href} href={href} onClick={() => setMobileOpen(false)} data-testid={`link-${label.toLowerCase().replaceAll(' ', '-')}`} className={cn('group flex items-center gap-3 rounded-lg px-3 py-2.5 text-xs transition', location === href ? 'bg-cyan-300/[.1] text-cyan-200' : 'text-slate-400 hover:bg-white/[.04] hover:text-slate-100')}>
          <Icon className={cn('h-4 w-4', location === href ? 'text-cyan-300' : 'text-slate-500 group-hover:text-slate-300')} />
          {label}
          {location === href && <ChevronRight className="ml-auto h-3.5 w-3.5 text-cyan-300" />}
        </Link>)}
      </nav>
      <div className="mt-auto rounded-xl border border-violet-300/15 bg-violet-400/[.05] p-4">
        <div className="flex items-center gap-2 text-xs font-semibold text-violet-100"><Shield className="h-4 w-4 text-violet-300" /> Vault protection</div>
        <p className="mt-2 text-[11px] leading-5 text-slate-400">Three online nodes are ready for your first object.</p>
        <div className="mt-3 flex items-center gap-2 text-[10px] text-emerald-300"><span className="status-pulse h-1.5 w-1.5 rounded-full bg-emerald-300" /> Cluster operational</div>
      </div>
      <div className="mt-5 flex items-center gap-3 border-t border-white/[.07] px-3 pt-5">
        <div className="grid h-7 w-7 place-items-center rounded-full bg-gradient-to-br from-cyan-300 to-violet-500 text-[10px] font-bold text-[#07101f]">OP</div>
        <div className="min-w-0"><div className="truncate text-xs text-slate-200">Operator</div><button type="button" className="truncate font-mono text-[9px] text-slate-500 hover:text-cyan-300" onClick={() => signOut({ redirectUrl: basePath || '/' })}>Sign out</button></div>
        <CircleHelp className="ml-auto h-4 w-4 text-slate-500" />
      </div>
    </aside>
    <div className="relative md:pl-[246px]">
      <header className="sticky top-0 z-30 flex h-[68px] items-center justify-between border-b border-cyan-100/10 bg-[#07101f]/80 px-5 backdrop-blur-xl md:px-9">
        <div className="flex items-center gap-3">
          <Button variant="quiet" className="md:hidden" onClick={() => setMobileOpen(true)} aria-label="Open navigation" data-testid="button-open-navigation"><Menu className="h-5 w-5" /></Button>
          <div className="hidden items-center gap-2 text-[11px] text-slate-500 md:flex"><span>VAULT</span><ChevronRight className="h-3 w-3" /><span className="text-slate-300">{nav.find((item) => item.href === location)?.label ?? 'Console'}</span></div>
          <div className="flex items-center gap-2 md:hidden"><BrandMark compact /></div>
        </div>
        <div className="flex items-center gap-3">
          <span className="hidden items-center gap-2 text-[10px] text-slate-500 sm:flex"><span className="h-1.5 w-1.5 rounded-full bg-emerald-300" /> API connected</span>
          <Link href="/settings" className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 text-slate-400 hover:bg-white/[.05] hover:text-slate-100" data-testid="link-header-settings"><Settings2 className="h-4 w-4" /></Link>
        </div>
      </header>
      {mobileOpen && <button className="fixed inset-0 z-30 bg-black/50 md:hidden" onClick={() => setMobileOpen(false)} aria-label="Close navigation" data-testid="button-close-navigation"><X className="absolute right-4 top-5 h-5 w-5 text-slate-300" /></button>}
      <main className="mx-auto max-w-[1440px] px-5 py-8 md:px-9">{children}</main>
    </div>
  </div>;
}

function PageIntro({ eyebrow, title, detail, action }: { eyebrow: string; title: string; detail: string; action?: ReactNode }) {
  return <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
    <div><div className="mb-2 font-mono text-[10px] uppercase tracking-[.22em] text-cyan-300/75">{eyebrow}</div><h1 className="text-2xl font-semibold tracking-tight text-slate-50 md:text-3xl">{title}</h1><p className="mt-2 max-w-xl text-sm text-slate-400">{detail}</p></div>
    {action && <div className="shrink-0">{action}</div>}
  </div>;
}

function MetricCard({ label, value, detail, icon: Icon, accent = 'cyan' }: { label: string; value: string | number; detail: string; icon: typeof Database; accent?: 'cyan' | 'violet' | 'amber' | 'rose' }) {
  return <div className="glass-surface rounded-xl p-5" data-testid={`metric-${label.toLowerCase().replaceAll(' ', '-')}`}>
    <div className="flex items-start justify-between"><div className={cn('grid h-9 w-9 place-items-center rounded-lg', accent === 'cyan' && 'bg-cyan-300/10 text-cyan-300', accent === 'violet' && 'bg-violet-300/10 text-violet-300', accent === 'amber' && 'bg-amber-300/10 text-amber-300', accent === 'rose' && 'bg-rose-300/10 text-rose-300')}><Icon className="h-4 w-4" /></div><span className="font-mono text-[10px] text-slate-500">LIVE</span></div>
    <div className="mt-5 text-2xl font-semibold tracking-tight text-slate-100">{value}</div><div className="mt-1 text-xs text-slate-400">{label}</div><div className="mt-3 text-[10px] text-slate-500">{detail}</div>
  </div>;
}

function DashboardPage() {
  const dashboardQuery = useGetDashboard({ query: { queryKey: getGetDashboardQueryKey(), staleTime: 20_000 } });
  const activityQuery = useListActivity({ query: { queryKey: getListActivityQueryKey(), staleTime: 20_000 } });
  const recoveryQuery = useListRecoveryJobs({ query: { queryKey: getListRecoveryJobsQueryKey(), staleTime: 20_000 } });
  const dashboard = dashboardQuery.data as Dashboard | undefined;
  const activity = (activityQuery.data ?? []) as ActivityEvent[];
  const jobs = (recoveryQuery.data ?? []) as RecoveryJob[];
  if (dashboardQuery.isLoading) return <DashboardSkeleton />;
  if (dashboardQuery.isError) return <ErrorState message={errorText(dashboardQuery.error)} retry={() => dashboardQuery.refetch()} />;
  if (!dashboard) return <ErrorState message="The cluster returned no dashboard data." retry={() => dashboardQuery.refetch()} />;
  return <div className="animate-rise">
    <PageIntro eyebrow="Cluster overview" title="Good morning, operator." detail="A precise view of object integrity, node health, and recovery posture across your Vault cluster." action={<Button variant="secondary" onClick={() => { dashboardQuery.refetch(); activityQuery.refetch(); recoveryQuery.refetch(); }} data-testid="button-refresh-dashboard"><RefreshCw className={cn('h-3.5 w-3.5', dashboardQuery.isFetching && 'animate-spin')} /> Refresh telemetry</Button>} />
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <MetricCard label="Objects stored" value={dashboard.objects} detail={`${dashboard.files} files in inventory`} icon={Database} />
      <MetricCard label="Storage used" value={formatBytes(dashboard.storageBytes)} detail="Across all storage nodes" icon={HardDrive} accent="violet" />
      <MetricCard label="Healthy replicas" value={dashboard.healthyReplicas} detail={`${dashboard.underReplicated} currently under replicated`} icon={ShieldCheck} accent={dashboard.underReplicated ? 'amber' : 'cyan'} />
      <MetricCard label="Recovery jobs" value={dashboard.recoveryJobs} detail={dashboard.corrupted ? `${dashboard.corrupted} corrupted objects` : 'No integrity incidents'} icon={Wrench} accent={dashboard.corrupted ? 'rose' : 'cyan'} />
    </div>
    <div className="mt-6 grid gap-6 xl:grid-cols-[1.45fr_1fr]">
      <section className="glass-surface rounded-xl p-5 md:p-6" data-testid="section-cluster-posture">
        <div className="flex items-center justify-between"><div><h2 className="text-sm font-semibold text-slate-100">Cluster posture</h2><p className="mt-1 text-xs text-slate-500">Online capacity and replication readiness</p></div><Link href="/nodes" className="flex items-center gap-1 text-[11px] text-cyan-300 hover:text-cyan-100" data-testid="link-view-nodes">View nodes <ChevronRight className="h-3 w-3" /></Link></div>
        <div className="mt-6 rounded-lg border border-white/[.07] bg-[#081427]/80 p-5">
          <div className="flex items-end justify-between"><div><span className="font-mono text-[10px] uppercase tracking-[.16em] text-slate-500">Storage allocation</span><div className="mt-2 text-xl font-semibold text-slate-100">{formatBytes(dashboard.storageBytes)} <span className="text-xs font-normal text-slate-500">used</span></div></div><div className="text-right"><div className="font-mono text-xs text-cyan-300">{dashboard.nodes.filter((node) => node.status === 'online').length}/{dashboard.nodes.length}</div><div className="mt-1 text-[10px] text-slate-500">nodes online</div></div></div>
          <div className="mt-5 h-2 overflow-hidden rounded-full bg-white/[.07]"><div className="h-full rounded-full bg-gradient-to-r from-cyan-300 to-violet-400" style={{ width: `${Math.min(100, Math.max(3, dashboard.nodes.reduce((sum, node) => sum + (node.capacityBytes ? node.usedBytes / node.capacityBytes : 0), 0) / Math.max(1, dashboard.nodes.length) * 100))}%` }} /></div>
          <div className="mt-5 grid gap-3 sm:grid-cols-3">{dashboard.nodes.map((node) => <div key={node.id} className="flex items-center gap-2.5" data-testid={`node-health-${node.id}`}><span className={cn('h-2 w-2 rounded-full', node.status === 'online' ? 'bg-emerald-300' : 'bg-rose-300')} /><div className="min-w-0"><div className="truncate text-xs text-slate-300">{node.name}</div><div className="font-mono text-[9px] text-slate-600">{formatBytes(node.usedBytes)} used</div></div></div>)}</div>
        </div>
        {dashboard.objects === 0 && <div className="mt-4 flex items-center gap-3 rounded-lg border border-cyan-300/15 bg-cyan-300/[.04] p-4"><Sparkles className="h-4 w-4 shrink-0 text-cyan-300" /><p className="text-xs leading-5 text-slate-400">Your cluster is clean and waiting. Upload the first object to start replicating across the three online nodes.</p><Link href="/files" className="ml-auto shrink-0 text-[11px] font-semibold text-cyan-300" data-testid="link-start-upload">Upload object</Link></div>}
      </section>
      <section className="glass-surface rounded-xl p-5 md:p-6" data-testid="section-recent-activity">
        <div className="flex items-center justify-between"><div><h2 className="text-sm font-semibold text-slate-100">Recent activity</h2><p className="mt-1 text-xs text-slate-500">Operations from the control plane</p></div><span className="font-mono text-[10px] text-slate-500">{dashboard.activity} EVENTS</span></div>
        {activityQuery.isLoading ? <div className="mt-6 space-y-4"><Skeleton className="h-10" /><Skeleton className="h-10" /><Skeleton className="h-10" /></div> : activity.length === 0 ? <div className="mt-5"><EmptyState icon={Zap} title="No operations yet" detail="Upload, verify, or repair an object and its event trail will appear here." /></div> : <div className="mt-5 space-y-1">{activity.slice(0, 6).map((event) => <ActivityRow event={event} key={event.id} />)}</div>}
      </section>
    </div>
    <section className="mt-6 glass-surface rounded-xl p-5 md:p-6" data-testid="section-recovery-jobs">
      <div className="flex items-center justify-between"><div><h2 className="text-sm font-semibold text-slate-100">Recovery queue</h2><p className="mt-1 text-xs text-slate-500">Self-healing work awaiting or completed</p></div><span className="font-mono text-[10px] text-slate-500">{jobs.length} JOBS</span></div>
      {recoveryQuery.isLoading ? <div className="mt-5 space-y-3"><Skeleton className="h-12" /><Skeleton className="h-12" /></div> : jobs.length === 0 ? <div className="mt-5"><EmptyState icon={Wrench} title="Recovery queue is empty" detail="Vault will place repair work here if a replica becomes unavailable or fails verification." /></div> : <div className="mt-5 overflow-x-auto"><table className="w-full min-w-[580px] text-left"><thead><tr className="border-b border-white/[.07] text-[10px] uppercase tracking-[.16em] text-slate-500"><th className="pb-3 font-medium">Object</th><th className="pb-3 font-medium">Reason</th><th className="pb-3 font-medium">Status</th><th className="pb-3 text-right font-medium">Updated</th></tr></thead><tbody>{jobs.map((job) => <tr key={job.id} className="border-b border-white/[.05] text-xs"><td className="py-3 font-mono text-slate-300">{shortHash(job.objectId)}</td><td className="py-3 text-slate-400">{job.reason}</td><td className="py-3"><StatusPill status={job.status} /></td><td className="py-3 text-right text-slate-500">{formatDate(job.updatedAt)}</td></tr>)}</tbody></table></div>}
    </section>
  </div>;
}

function DashboardSkeleton() {
  return <div className="space-y-6" data-testid="dashboard-loading"><div className="space-y-3"><Skeleton className="h-3 w-28" /><Skeleton className="h-9 w-72" /><Skeleton className="h-4 w-96 max-w-full" /></div><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{[1, 2, 3, 4].map((item) => <Skeleton key={item} className="h-36" />)}</div><div className="grid gap-6 xl:grid-cols-[1.45fr_1fr]"><Skeleton className="h-80" /><Skeleton className="h-80" /></div></div>;
}

function ActivityRow({ event }: { event: ActivityEvent }) {
  return <div className="flex gap-3 rounded-lg px-2 py-3 hover:bg-white/[.03]" data-testid={`activity-${event.id}`}><div className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-md bg-cyan-300/10 text-cyan-300"><Zap className="h-3.5 w-3.5" /></div><div className="min-w-0 flex-1"><div className="flex items-start justify-between gap-2"><p className="text-xs font-medium text-slate-200">{event.title}</p><span className="shrink-0 text-[10px] text-slate-600">{formatDate(event.createdAt)}</span></div><p className="mt-1 truncate text-[11px] text-slate-500">{event.detail}</p></div></div>;
}

function FileIcon({ filename }: { filename: string }) {
  const extension = filename.split('.').pop()?.toLowerCase();
  return extension === 'zip' || extension === 'gz' ? <FileArchive className="h-4 w-4" /> : extension === 'json' || extension === 'ts' ? <FileCode2 className="h-4 w-4" /> : <FileText className="h-4 w-4" />;
}

function DownloadAction({ object }: { object: VaultObject }) {
  const download = useDownloadObject(object.id, { query: { enabled: false, queryKey: getDownloadObjectQueryKey(object.id) } });
  const [busy, setBusy] = useState(false);
  const handle = async () => {
    setBusy(true);
    try {
      const result = await download.refetch();
      if (result.data instanceof Blob) {
        const url = URL.createObjectURL(result.data);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = object.filename;
        anchor.click();
        URL.revokeObjectURL(url);
      }
    } finally { setBusy(false); }
  };
  return <Button variant="quiet" className="px-2" onClick={handle} disabled={busy} title="Download object" data-testid={`button-download-${object.id}`}><Download className="h-3.5 w-3.5" /></Button>;
}

function FilesPage() {
  const objectsQuery = useListObjects({ query: { queryKey: getListObjectsQueryKey(), staleTime: 15_000 } });
  const client = useQueryClient();
  const fileInput = useRef<HTMLInputElement>(null);
  const [notice, setNotice] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const upload = useUploadObject();
  const remove = useDeleteObject();
  const verify = useVerifyObject();
  const repair = useRepairObject();
  const objects = (objectsQuery.data ?? []) as VaultObject[];
  const refresh = () => { client.invalidateQueries({ queryKey: getListObjectsQueryKey() }); client.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); };
  const uploadFile = (file?: File) => {
    if (!file) return;
    setNotice(null);
    upload.mutate({ data: { file } }, { onSuccess: () => { setNotice({ type: 'success', text: `${file.name} uploaded and replication started.` }); refresh(); }, onError: (error) => setNotice({ type: 'error', text: errorText(error) }) });
  };
  const runObjectAction = (kind: 'verify' | 'repair', objectId: string) => {
    const mutation = kind === 'verify' ? verify : repair;
    mutation.mutate({ objectId }, { onSuccess: () => { setNotice({ type: 'success', text: kind === 'verify' ? 'Replica checks completed.' : 'Repair job queued.' }); refresh(); }, onError: (error) => setNotice({ type: 'error', text: errorText(error) }) });
  };
  const deleteFile = (object: VaultObject) => {
    if (!window.confirm(`Delete ${object.filename} and all replicas?`)) return;
    remove.mutate({ objectId: object.id }, { onSuccess: () => { setNotice({ type: 'success', text: `${object.filename} deleted.` }); refresh(); }, onError: (error) => setNotice({ type: 'error', text: errorText(error) }) });
  };
  return <div className="animate-rise">
    <PageIntro eyebrow="Object inventory" title="Files, accounted for." detail="Every object is addressed, replicated, and verifiable. Upload into the cluster or inspect the physical copies behind it." action={<><input ref={fileInput} className="hidden" type="file" onChange={(event) => uploadFile(event.target.files?.[0])} data-testid="input-upload-file" /><Button onClick={() => fileInput.current?.click()} disabled={upload.isPending} data-testid="button-upload-object"><UploadCloud className="h-4 w-4" />{upload.isPending ? 'Replicating…' : 'Upload object'}</Button></>} />
    {notice && <div className={cn('mb-5 flex items-center gap-3 rounded-lg border px-4 py-3 text-xs', notice.type === 'success' ? 'border-emerald-300/20 bg-emerald-300/[.07] text-emerald-200' : 'border-rose-300/20 bg-rose-300/[.07] text-rose-200')} data-testid="operation-notice"><CheckCircle2 className="h-4 w-4" />{notice.text}<button className="ml-auto" onClick={() => setNotice(null)} aria-label="Dismiss notice" data-testid="button-dismiss-notice"><X className="h-4 w-4" /></button></div>}
    <section className="glass-surface overflow-hidden rounded-xl" data-testid="section-object-inventory">
      <div className="flex flex-col justify-between gap-3 border-b border-white/[.07] p-5 sm:flex-row sm:items-center"><div><h2 className="text-sm font-semibold text-slate-100">Stored objects</h2><p className="mt-1 text-xs text-slate-500">{objects.length} object{objects.length === 1 ? '' : 's'} registered in the cluster</p></div><Button variant="quiet" onClick={() => objectsQuery.refetch()} data-testid="button-refresh-objects"><RefreshCw className={cn('h-3.5 w-3.5', objectsQuery.isFetching && 'animate-spin')} /> Refresh</Button></div>
      {objectsQuery.isLoading ? <div className="space-y-3 p-5"><Skeleton className="h-14" /><Skeleton className="h-14" /><Skeleton className="h-14" /></div> : objectsQuery.isError ? <div className="p-5"><ErrorState message={errorText(objectsQuery.error)} retry={() => objectsQuery.refetch()} /></div> : objects.length === 0 ? <div className="p-5"><EmptyState icon={CloudUpload} title="No objects in Vault yet" detail="Your first upload will be distributed across the three online nodes and appear here with its checksum and replica health." action={<Button onClick={() => fileInput.current?.click()} data-testid="button-upload-first-object"><Plus className="h-4 w-4" /> Upload your first object</Button>} /></div> : <div className="overflow-x-auto"><table className="w-full min-w-[850px] text-left"><thead><tr className="border-b border-white/[.07] text-[10px] uppercase tracking-[.16em] text-slate-500"><th className="px-5 py-3 font-medium">Object</th><th className="py-3 font-medium">Integrity</th><th className="py-3 font-medium">Replicas</th><th className="py-3 font-medium">Size</th><th className="py-3 font-medium">Updated</th><th className="px-5 py-3 text-right font-medium">Actions</th></tr></thead><tbody>{objects.map((object) => <tr key={object.id} className="border-b border-white/[.05] transition hover:bg-white/[.025]" data-testid={`row-object-${object.id}`}><td className="px-5 py-4"><div className="flex items-center gap-3"><div className="grid h-8 w-8 place-items-center rounded-lg bg-violet-300/10 text-violet-300"><FileIcon filename={object.filename} /></div><div><div className="max-w-[240px] truncate text-xs font-medium text-slate-200">{object.filename}</div><div className="mt-1 font-mono text-[9px] text-slate-600">{shortHash(object.checksum)}</div></div></div></td><td className="py-4"><StatusPill status={object.status} /><div className="mt-1 text-[10px] text-slate-600">{object.risk} risk</div></td><td className="py-4"><span className="font-mono text-xs text-slate-300">{object.healthyReplicas}/{object.replicationFactor}</span><div className="mt-1 flex gap-1">{Array.from({ length: object.replicationFactor }).map((_, index) => <span key={index} className={cn('h-1 w-5 rounded-full', index < object.healthyReplicas ? 'bg-cyan-300' : 'bg-rose-300/40')} />)}</div></td><td className="py-4 font-mono text-xs text-slate-400">{formatBytes(object.sizeBytes)}</td><td className="py-4 text-xs text-slate-500">{formatDate(object.updatedAt)}</td><td className="px-5 py-4"><div className="flex justify-end gap-1"><DownloadAction object={object} /><Button variant="quiet" className="px-2" onClick={() => runObjectAction('verify', object.id)} disabled={verify.isPending} title="Verify replicas" data-testid={`button-verify-${object.id}`}><ShieldCheck className="h-3.5 w-3.5" /></Button><Button variant="quiet" className="px-2" onClick={() => runObjectAction('repair', object.id)} disabled={repair.isPending} title="Repair object" data-testid={`button-repair-${object.id}`}><Wrench className="h-3.5 w-3.5" /></Button><Button variant="quiet" className="px-2 text-rose-300 hover:text-rose-200" onClick={() => deleteFile(object)} disabled={remove.isPending} title="Delete object" data-testid={`button-delete-${object.id}`}><Trash2 className="h-3.5 w-3.5" /></Button></div></td></tr>)}</tbody></table></div>}
    </section>
  </div>;
}

function NodesPage() {
  const nodesQuery = useListNodes({ query: { queryKey: getListNodesQueryKey(), staleTime: 15_000 } });
  const client = useQueryClient();
  const [notice, setNotice] = useState<string | null>(null);
  const fail = useFailNode();
  const restore = useRestoreNode();
  const corrupt = useCorruptReplica();
  const replace = useReplaceNode();
  const nodes = (nodesQuery.data ?? []) as StorageNode[];
  const refresh = () => { client.invalidateQueries({ queryKey: getListNodesQueryKey() }); client.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); };
  const run = (action: 'fail' | 'restore' | 'corrupt', node: StorageNode) => {
    if (action === 'fail' && !window.confirm(`Mark ${node.name} as destroyed for development testing?`)) return;
    const mutation = action === 'fail' ? fail : action === 'restore' ? restore : corrupt;
    mutation.mutate({ nodeId: node.id }, { onSuccess: () => { setNotice(action === 'corrupt' ? `A replica on ${node.name} was marked corrupted.` : `${node.name} is now ${action === 'fail' ? 'offline' : 'online'}.`); refresh(); }, onError: (error) => setNotice(errorText(error)) });
  };
  return <div className="animate-rise">
    <PageIntro eyebrow="Storage topology" title="Nodes under watch." detail="Inspect capacity, heartbeat, and replica behavior. Failure and corruption controls are available for development testing." action={<Button variant="secondary" onClick={() => nodesQuery.refetch()} data-testid="button-refresh-nodes"><RefreshCw className={cn('h-3.5 w-3.5', nodesQuery.isFetching && 'animate-spin')} /> Refresh nodes</Button>} />
    {notice && <div className="mb-5 flex items-center gap-3 rounded-lg border border-cyan-300/20 bg-cyan-300/[.06] px-4 py-3 text-xs text-cyan-100" data-testid="node-operation-notice"><Check className="h-4 w-4 text-cyan-300" />{notice}<button className="ml-auto text-slate-400" onClick={() => setNotice(null)} data-testid="button-dismiss-node-notice"><X className="h-4 w-4" /></button></div>}
    {nodesQuery.isLoading ? <div className="grid gap-5 lg:grid-cols-3">{[1,2,3].map((item) => <Skeleton key={item} className="h-72" />)}</div> : nodesQuery.isError ? <ErrorState message={errorText(nodesQuery.error)} retry={() => nodesQuery.refetch()} /> : nodes.length === 0 ? <EmptyState icon={Server} title="No storage nodes registered" detail="Vault has no node telemetry to display." /> : <div className="grid gap-5 lg:grid-cols-3">{nodes.map((node) => <NodeCard key={node.id} node={node} onAction={run} busy={fail.isPending || restore.isPending || corrupt.isPending} />)}</div>}
    <section className="mt-6 glass-surface rounded-xl p-5 md:p-6" data-testid="section-node-replacement"><div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center"><div><div className="flex items-center gap-2 text-sm font-semibold text-slate-100"><RotateCcw className="h-4 w-4 text-violet-300" /> Replacement capacity</div><p className="mt-2 max-w-xl text-xs leading-5 text-slate-500">Create a fresh node when a destroyed node needs to be replaced. Automatic replacement can be enabled in settings.</p></div><Button variant="secondary" onClick={() => replace.mutate(undefined, { onSuccess: () => { setNotice('Replacement node created and added to the topology.'); refresh(); }, onError: (error) => setNotice(errorText(error)) })} disabled={replace.isPending} data-testid="button-replace-node"><Plus className="h-4 w-4" />{replace.isPending ? 'Provisioning…' : 'Create replacement node'}</Button></div></section>
  </div>;
}

function NodeCard({ node, onAction, busy }: { node: StorageNode; onAction: (action: 'fail' | 'restore' | 'corrupt', node: StorageNode) => void; busy: boolean }) {
  const usage = node.capacityBytes ? Math.round(node.usedBytes / node.capacityBytes * 100) : 0;
  return <article className="glass-surface rounded-xl p-5" data-testid={`card-node-${node.id}`}>
    <div className="flex items-start justify-between"><div className="flex items-center gap-3"><div className={cn('grid h-10 w-10 place-items-center rounded-lg', node.status === 'online' ? 'bg-emerald-300/10 text-emerald-300' : 'bg-rose-300/10 text-rose-300')}><Server className="h-5 w-5" /></div><div><h2 className="text-sm font-semibold text-slate-100">{node.name}</h2><p className="mt-1 font-mono text-[10px] text-slate-500">{node.host}:{node.port}</p></div></div><StatusPill status={node.status} /></div>
    <div className="mt-6"><div className="flex justify-between text-[10px] uppercase tracking-[.14em] text-slate-500"><span>Capacity used</span><span className="font-mono text-slate-300">{usage}%</span></div><div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/[.07]"><div className={cn('h-full rounded-full', usage > 85 ? 'bg-amber-300' : 'bg-gradient-to-r from-cyan-300 to-violet-400')} style={{ width: `${usage}%` }} /></div><div className="mt-2 flex justify-between font-mono text-[10px] text-slate-600"><span>{formatBytes(node.usedBytes)} used</span><span>{formatBytes(node.capacityBytes)} total</span></div></div>
    <div className="mt-5 grid grid-cols-2 gap-3 border-y border-white/[.07] py-4"><div><div className="text-[10px] uppercase tracking-[.14em] text-slate-600">Objects</div><div className="mt-1 font-mono text-sm text-slate-300">{node.objectCount}</div></div><div><div className="text-[10px] uppercase tracking-[.14em] text-slate-600">Heartbeat</div><div className="mt-1 flex items-center gap-1.5 text-xs text-slate-300"><HeartPulse className="h-3 w-3 text-cyan-300" />{formatDate(node.heartbeat)}</div></div></div>
    <div className="flex items-center justify-between text-[10px] text-slate-600"><span>Last seen {formatDate(node.lastSeen)}</span><span>{node.failureState || 'nominal'}</span></div>
    <div className="mt-5 flex flex-wrap gap-2">{node.status === 'online' ? <><Button variant="danger" onClick={() => onAction('fail', node)} disabled={busy} data-testid={`button-fail-node-${node.id}`}><AlertTriangle className="h-3.5 w-3.5" /> Fail node</Button><Button variant="quiet" onClick={() => onAction('corrupt', node)} disabled={busy} data-testid={`button-corrupt-node-${node.id}`}><Zap className="h-3.5 w-3.5" /> Corrupt replica</Button></> : <Button variant="secondary" onClick={() => onAction('restore', node)} disabled={busy} data-testid={`button-restore-node-${node.id}`}><RefreshCw className="h-3.5 w-3.5" /> Restore node</Button>}</div>
  </article>;
}

function SettingsPage() {
  const settingsQuery = useGetSettings({ query: { queryKey: getGetSettingsQueryKey(), staleTime: 30_000 } });
  const client = useQueryClient();
  const update = useUpdateSettings();
  const reset = useResetVault();
  const [form, setForm] = useState<VaultSettings | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  useEffect(() => { if (settingsQuery.data) setForm(settingsQuery.data as VaultSettings); }, [settingsQuery.data]);
  const patch = <K extends keyof VaultSettings>(key: K, value: VaultSettings[K]) => setForm((current) => current ? { ...current, [key]: value } : current);
  const save = () => {
    if (!form) return;
    update.mutate({ data: { systemName: form.systemName, description: form.description, replicationFactor: Number(form.replicationFactor), automaticNodeReplacement: form.automaticNodeReplacement, automaticReplicaRepair: form.automaticReplicaRepair, checkIntervalSeconds: Number(form.checkIntervalSeconds), maxFileSizeBytes: Number(form.maxFileSizeBytes) } }, { onSuccess: () => { setNotice('Vault settings saved.'); client.invalidateQueries({ queryKey: getGetSettingsQueryKey() }); client.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); }, onError: (error) => setNotice(errorText(error)) });
  };
  const resetVault = () => {
    if (!window.confirm('Reset Vault data? This removes all objects, events, and recovery jobs.')) return;
    reset.mutate(undefined, { onSuccess: () => { setNotice('Vault reset complete.'); client.invalidateQueries(); }, onError: (error) => setNotice(errorText(error)) });
  };
  if (settingsQuery.isLoading || !form) return <div className="space-y-5"><Skeleton className="h-20 w-2/3" /><Skeleton className="h-96" /></div>;
  if (settingsQuery.isError) return <ErrorState message={errorText(settingsQuery.error)} retry={() => settingsQuery.refetch()} />;
  return <div className="animate-rise">
    <PageIntro eyebrow="Cluster configuration" title="Settings that hold the line." detail="Define how Vault replicates, checks, and responds when the topology changes." action={<Button onClick={save} disabled={update.isPending} data-testid="button-save-settings"><Check className="h-4 w-4" />{update.isPending ? 'Saving…' : 'Save settings'}</Button>} />
    {notice && <div className="mb-5 flex items-center gap-3 rounded-lg border border-cyan-300/20 bg-cyan-300/[.06] px-4 py-3 text-xs text-cyan-100" data-testid="settings-notice"><CheckCircle2 className="h-4 w-4 text-cyan-300" />{notice}</div>}
    <div className="grid gap-6 xl:grid-cols-[1.2fr_.8fr]">
      <section className="glass-surface rounded-xl p-5 md:p-7" data-testid="section-general-settings"><div className="mb-6 flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-lg bg-cyan-300/10 text-cyan-300"><Settings2 className="h-4 w-4" /></div><div><h2 className="text-sm font-semibold text-slate-100">General</h2><p className="mt-1 text-xs text-slate-500">How your cluster is identified</p></div></div><div className="space-y-5"><Field label="System name" detail="Shown in the console header and operational events"><input value={form.systemName} onChange={(event) => patch('systemName', event.target.value)} className="console-input" data-testid="input-system-name" /></Field><Field label="Description" detail="A short description for operators"><textarea value={form.description} onChange={(event) => patch('description', event.target.value)} className="console-input min-h-[92px] resize-y" data-testid="input-system-description" /></Field></div></section>
      <section className="glass-surface rounded-xl p-5 md:p-7" data-testid="section-replication-settings"><div className="mb-6 flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-lg bg-violet-300/10 text-violet-300"><Shield className="h-4 w-4" /></div><div><h2 className="text-sm font-semibold text-slate-100">Replication policy</h2><p className="mt-1 text-xs text-slate-500">The rules behind every upload</p></div></div><div className="space-y-5"><Field label="Replication factor" detail="Number of physical copies (1–5)"><input type="number" min={1} max={5} value={form.replicationFactor} onChange={(event) => patch('replicationFactor', Number(event.target.value))} className="console-input" data-testid="input-replication-factor" /></Field><Toggle label="Automatic replica repair" detail="Rebuild unavailable or corrupted copies" checked={form.automaticReplicaRepair} onChange={(value) => patch('automaticReplicaRepair', value)} testId="toggle-automatic-repair" /><Toggle label="Automatic node replacement" detail="Provision a replacement for destroyed nodes" checked={form.automaticNodeReplacement} onChange={(value) => patch('automaticNodeReplacement', value)} testId="toggle-automatic-replacement" /></div></section>
      <section className="glass-surface rounded-xl p-5 md:p-7" data-testid="section-monitoring-settings"><div className="mb-6 flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-lg bg-amber-300/10 text-amber-300"><HeartPulse className="h-4 w-4" /></div><div><h2 className="text-sm font-semibold text-slate-100">Monitoring</h2><p className="mt-1 text-xs text-slate-500">Integrity check cadence and limits</p></div></div><div className="space-y-5"><Field label="Check interval" detail="Seconds between integrity checks (minimum 10)"><div className="relative"><input type="number" min={10} value={form.checkIntervalSeconds} onChange={(event) => patch('checkIntervalSeconds', Number(event.target.value))} className="console-input pr-16" data-testid="input-check-interval" /><span className="pointer-events-none absolute right-3 top-2.5 font-mono text-[10px] text-slate-600">SECONDS</span></div></Field><Field label="Maximum file size" detail="Maximum accepted upload size in bytes"><input type="number" min={1} value={form.maxFileSizeBytes} onChange={(event) => patch('maxFileSizeBytes', Number(event.target.value))} className="console-input" data-testid="input-max-file-size" /><div className="mt-2 font-mono text-[10px] text-slate-500">{formatBytes(Number(form.maxFileSizeBytes))}</div></Field></div></section>
      <section className="glass-surface rounded-xl border-rose-300/15 p-5 md:p-7" data-testid="section-danger-zone"><div className="mb-5 flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-lg bg-rose-300/10 text-rose-300"><Trash2 className="h-4 w-4" /></div><div><h2 className="text-sm font-semibold text-slate-100">Danger zone</h2><p className="mt-1 text-xs text-slate-500">Development-only destructive operations</p></div></div><p className="text-xs leading-5 text-slate-400">Resetting Vault clears all stored objects, activity, and recovery jobs while keeping your node topology and settings.</p><Button className="mt-5" variant="danger" onClick={resetVault} disabled={reset.isPending} data-testid="button-reset-vault"><Trash2 className="h-3.5 w-3.5" />{reset.isPending ? 'Resetting…' : 'Reset Vault data'}</Button></section>
    </div>
  </div>;
}

function Field({ label, detail, children }: { label: string; detail: string; children: ReactNode }) {
  return <label className="block"><span className="text-xs font-medium text-slate-200">{label}</span><span className="mt-1 block text-[10px] leading-4 text-slate-500">{detail}</span><div className="mt-2">{children}</div></label>;
}

function Toggle({ label, detail, checked, onChange, testId }: { label: string; detail: string; checked: boolean; onChange: (value: boolean) => void; testId: string }) {
  return <div className="flex items-start justify-between gap-4"><div><div className="text-xs font-medium text-slate-200">{label}</div><div className="mt-1 text-[10px] leading-4 text-slate-500">{detail}</div></div><button type="button" role="switch" aria-checked={checked} onClick={() => onChange(!checked)} className={cn('relative mt-0.5 h-6 w-11 shrink-0 rounded-full border transition', checked ? 'border-cyan-300/40 bg-cyan-300/25' : 'border-white/10 bg-white/[.06]')} data-testid={testId}><span className={cn('absolute top-1 h-3.5 w-3.5 rounded-full transition', checked ? 'left-6 bg-cyan-200' : 'left-1 bg-slate-500')} /></button></div>;
}

function LandingPage() {
  return <div className="min-h-[100dvh] overflow-hidden bg-[#07101f] text-slate-100">
    <div className="pointer-events-none fixed inset-0"><div className="absolute left-[-10%] top-[18%] h-[32rem] w-[32rem] rounded-full bg-cyan-400/[.06] blur-3xl" /><div className="absolute right-[-10%] top-[30%] h-[28rem] w-[28rem] rounded-full bg-violet-500/[.07] blur-3xl" /></div>
    <nav className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-6 py-7"><BrandMark /><div className="flex items-center gap-3"><Link href="/sign-in" className="rounded-lg px-4 py-2 text-xs font-semibold text-slate-300 hover:bg-white/[.05]" data-testid="link-landing-sign-in">Sign in</Link><Link href="/sign-up" className="rounded-lg border border-cyan-300/30 bg-cyan-300/[.09] px-4 py-2 text-xs font-semibold text-cyan-100 hover:bg-cyan-300/[.15]" data-testid="link-landing-sign-up">Create account</Link></div></nav>
    <main className="relative z-10 mx-auto max-w-6xl px-6">
      <section className="grid min-h-[690px] items-center gap-14 py-20 lg:grid-cols-[1.05fr_.95fr]"><div><div className="mb-7 inline-flex items-center gap-2 rounded-full border border-cyan-300/20 bg-cyan-300/[.06] px-3 py-1.5 font-mono text-[10px] uppercase tracking-[.16em] text-cyan-200"><span className="h-1.5 w-1.5 rounded-full bg-cyan-300" /> Distributed object storage</div><h1 className="max-w-2xl text-5xl font-semibold leading-[1.02] tracking-[-.045em] text-slate-50 md:text-7xl">Your data.<br /><span className="bg-gradient-to-r from-cyan-200 via-cyan-300 to-violet-400 bg-clip-text text-transparent">Everywhere it needs to be.</span></h1><p className="mt-7 max-w-xl text-base leading-7 text-slate-400">Vault stores each object across isolated nodes, checks every replica, and gives you a clear path back when the unexpected happens.</p><div className="mt-9 flex flex-wrap gap-3"><Link href="/sign-up" className="inline-flex items-center gap-2 rounded-lg bg-cyan-300 px-5 py-3 text-xs font-bold text-[#07101f] shadow-[0_0_28px_rgba(35,210,255,.18)] hover:bg-cyan-200" data-testid="link-hero-start">Start with Vault <ChevronRight className="h-4 w-4" /></Link><Link href="/dashboard" className="inline-flex items-center gap-2 rounded-lg border border-white/10 px-5 py-3 text-xs font-semibold text-slate-300 hover:bg-white/[.05]" data-testid="link-hero-console">View console <ArrowDownToLine className="h-4 w-4" /></Link></div><div className="mt-14 flex flex-wrap gap-x-7 gap-y-3 font-mono text-[10px] uppercase tracking-[.14em] text-slate-600"><span className="flex items-center gap-2"><LockKeyhole className="h-3.5 w-3.5 text-cyan-300/70" /> End-to-end protection</span><span className="flex items-center gap-2"><Network className="h-3.5 w-3.5 text-violet-300/70" /> Isolated nodes</span><span className="flex items-center gap-2"><Wrench className="h-3.5 w-3.5 text-cyan-300/70" /> Self-healing</span></div></div><div className="relative"><div className="absolute -inset-8 rounded-full bg-cyan-300/[.04] blur-3xl" /><div className="glass-surface relative rounded-2xl p-5 md:p-7"><div className="mb-6 flex items-center justify-between"><div><div className="font-mono text-[10px] uppercase tracking-[.18em] text-cyan-300/70">Vault / live posture</div><div className="mt-2 text-sm font-semibold text-slate-100">Integrity at a glance</div></div><div className="flex items-center gap-2 rounded-full border border-emerald-300/20 bg-emerald-300/[.07] px-2.5 py-1 text-[10px] text-emerald-300"><span className="h-1.5 w-1.5 rounded-full bg-emerald-300" /> OPERATIONAL</div></div><div className="grid grid-cols-2 gap-3"><div className="rounded-xl border border-white/[.08] bg-[#09172d] p-4"><ShieldCheck className="h-4 w-4 text-cyan-300" /><div className="mt-5 font-mono text-2xl text-slate-100">3/3</div><div className="mt-1 text-[10px] text-slate-500">nodes online</div></div><div className="rounded-xl border border-white/[.08] bg-[#09172d] p-4"><HeartPulse className="h-4 w-4 text-violet-300" /><div className="mt-5 font-mono text-2xl text-slate-100">0</div><div className="mt-1 text-[10px] text-slate-500">recovery jobs</div></div></div><div className="mt-3 rounded-xl border border-white/[.08] bg-[#09172d] p-4"><div className="flex items-center justify-between"><span className="font-mono text-[10px] uppercase tracking-[.14em] text-slate-500">Replica verification</span><span className="text-[10px] text-cyan-300">READY</span></div><div className="mt-4 flex items-center gap-2">{[1,2,3,4,5,6,7,8].map((item) => <span key={item} className="h-7 flex-1 rounded-sm bg-gradient-to-t from-cyan-400/20 to-cyan-300/70" style={{ opacity: .45 + item / 20 }} />)}</div><div className="mt-3 flex justify-between text-[10px] text-slate-600"><span>checksum ledger</span><span>SHA-256</span></div></div><div className="mt-5 flex items-center gap-2 border-t border-white/[.07] pt-5"><div className="grid h-7 w-7 place-items-center rounded-full bg-violet-300/10 text-violet-300"><Zap className="h-3.5 w-3.5" /></div><div className="text-[11px] text-slate-400">A system designed to tell you the truth.</div></div></div></div></section>
      <section className="grid gap-4 border-y border-white/[.07] py-16 md:grid-cols-3"><Feature icon={UploadCloud} title="Store once" detail="One upload becomes a distributed object with a known checksum and a deliberate home across your nodes." /><Feature icon={ShieldCheck} title="Verify always" detail="Run checks against every physical replica. See what is healthy, what is missing, and what needs attention." /><Feature icon={Wrench} title="Recover clearly" detail="When a node fails, Vault queues the work, repairs the object, and keeps the operational trail visible." /></section>
      <section className="flex flex-col justify-between gap-8 py-24 md:flex-row md:items-end"><div><div className="font-mono text-[10px] uppercase tracking-[.2em] text-violet-300/80">The Vault principle</div><h2 className="mt-5 max-w-2xl text-3xl font-semibold leading-tight tracking-[-.03em] text-slate-100 md:text-5xl">No black boxes.<br /><span className="text-slate-500">No quiet failures.</span></h2></div><p className="max-w-sm text-sm leading-7 text-slate-400">The console is built for the moments after a system says “fine.” Inspect the nodes. Follow the replicas. Repair with confidence.</p></section>
    </main>
    <footer className="relative z-10 border-t border-white/[.07] px-6 py-8"><div className="mx-auto flex max-w-6xl flex-col gap-3 text-[10px] text-slate-600 sm:flex-row sm:items-center sm:justify-between"><BrandMark compact /><span className="font-mono">STORE · PROTECT · RECOVER / VAULT CONSOLE</span></div></footer>
  </div>;
}

function Feature({ icon: Icon, title, detail }: { icon: typeof UploadCloud; title: string; detail: string }) {
  return <div className="rounded-xl border border-white/[.07] bg-white/[.02] p-5"><div className="grid h-9 w-9 place-items-center rounded-lg bg-cyan-300/10 text-cyan-300"><Icon className="h-4 w-4" /></div><h3 className="mt-5 text-sm font-semibold text-slate-100">{title}</h3><p className="mt-2 text-xs leading-5 text-slate-500">{detail}</p></div>;
}

function AuthPage({ mode }: { mode: 'sign-in' | 'sign-up' }) {
  return <div className="noise flex min-h-[100dvh] items-center justify-center overflow-hidden bg-[#07101f] px-4 py-10 text-slate-100"><div className="pointer-events-none fixed inset-0"><div className="absolute bottom-[-20%] left-[12%] h-[28rem] w-[40rem] rounded-full bg-cyan-400/[.06] blur-3xl" /><div className="absolute right-[5%] top-[5%] h-[20rem] w-[20rem] rounded-full bg-violet-500/[.06] blur-3xl" /></div><div className="relative grid w-full max-w-5xl gap-10 lg:grid-cols-[.8fr_1fr] lg:items-center"><div className="hidden lg:block"><Link href="/" data-testid="link-auth-brand"><BrandMark /></Link><h1 className="mt-24 text-5xl font-light leading-[1.08] tracking-[-.04em] text-slate-100">Your data.<br />Your control.<br /><span className="text-cyan-300">Always.</span></h1><div className="mt-10 space-y-4 text-xs text-slate-400"><div className="flex items-center gap-3"><LockKeyhole className="h-4 w-4 text-cyan-300" /> End-to-end protection</div><div className="flex items-center gap-3"><Zap className="h-4 w-4 text-violet-300" /> Self-healing system</div><div className="flex items-center gap-3"><Network className="h-4 w-4 text-cyan-300" /> Distributed nodes</div></div></div><div className="mx-auto w-full max-w-[460px]"><div className="mb-8 lg:hidden"><Link href="/" data-testid="link-auth-brand-mobile"><BrandMark /></Link></div>{mode === 'sign-in' ? <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} appearance={clerkAppearance} /> : <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} appearance={clerkAppearance} />}<p className="mt-5 text-center font-mono text-[9px] uppercase tracking-[.16em] text-slate-700">VAULT / STORE · PROTECT · RECOVER</p></div></div></div>;
}

function ProtectedRoute({ children }: { children: ReactNode }) {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <div className="min-h-[100dvh] bg-[#07101f]" />;
  if (!isSignedIn) return <Redirect to="/sign-in" />;
  return <>{children}</>;
}

function AppRouter() {
  return <Switch>
    <Route path="/" component={LandingPage} />
    <Route path="/sign-in/*?" component={() => <AuthPage mode="sign-in" />} />
    <Route path="/sign-up/*?" component={() => <AuthPage mode="sign-up" />} />
    <Route path="/dashboard"><ProtectedRoute><AppShell><DashboardPage /></AppShell></ProtectedRoute></Route>
    <Route path="/files"><ProtectedRoute><AppShell><FilesPage /></AppShell></ProtectedRoute></Route>
    <Route path="/nodes"><ProtectedRoute><AppShell><NodesPage /></AppShell></ProtectedRoute></Route>
    <Route path="/settings"><ProtectedRoute><AppShell><SettingsPage /></AppShell></ProtectedRoute></Route>
    <Route component={NotFound} />
  </Switch>;
}

function App() {
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={clerkAppearance} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`}><QueryClientProvider client={queryClient}><WouterRouter base={basePath}><ErrorBoundary resetKey={window.location.pathname}><AppRouter /></ErrorBoundary></WouterRouter></QueryClientProvider></ClerkProvider>;
}

export default App;