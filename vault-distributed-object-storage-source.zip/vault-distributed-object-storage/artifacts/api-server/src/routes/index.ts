import { Router, type IRouter } from "express";
import { getAuth } from "@clerk/express";
import healthRouter from "./health";
import vaultRouter from "./vault";

const router: IRouter = Router();

router.use(healthRouter);
router.use((req, res, next) => {
  const auth = getAuth(req);
  if (!auth.userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}, vaultRouter);

export default router;
