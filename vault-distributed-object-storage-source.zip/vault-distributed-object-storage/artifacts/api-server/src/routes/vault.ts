import { Router, type IRouter } from "express";
import multer from "multer";
import {
  corruptReplica,
  deleteObject,
  downloadObject,
  failNode,
  getDashboard,
  getSettings,
  listActivity,
  listNodes,
  listObjects,
  listRecoveryJobs,
  replaceNode,
  repairObject,
  resetVault,
  restoreNode,
  updateSettings,
  uploadObject,
  verifyObject,
} from "../lib/vault-store";

const router: IRouter = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 * 1024 } });

function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : "Vault operation failed";
}

router.get("/dashboard", async (_req, res) => {
  try {
    res.json(await getDashboard());
  } catch (error) {
    res.status(500).json({ error: errorMessage(error) });
  }
});

router.get("/objects", async (_req, res) => {
  try {
    res.json(await listObjects());
  } catch (error) {
    res.status(500).json({ error: errorMessage(error) });
  }
});

router.post("/objects", upload.single("file"), async (req, res): Promise<void> => {
  try {
    if (!req.file) {
      res.status(400).json({ error: "A file is required" });
      return;
    }
    res.status(201).json(await uploadObject(req.file.originalname, req.file.buffer));
  } catch (error) {
    res.status(400).json({ error: errorMessage(error) });
  }
});

router.delete("/objects/:objectId", async (req, res) => {
  try {
    await deleteObject(req.params.objectId);
    res.status(204).send();
  } catch (error) {
    res.status(errorMessage(error) === "Object not found" ? 404 : 400).json({ error: errorMessage(error) });
  }
});

router.get("/objects/:objectId/download", async (req, res) => {
  try {
    const { object, bytes } = await downloadObject(req.params.objectId);
    res.setHeader("Content-Disposition", `attachment; filename="${object.filename.replace(/"/g, "")}"`);
    res.type("application/octet-stream").send(bytes);
  } catch (error) {
    res.status(errorMessage(error) === "Object not found" ? 404 : 409).json({ error: errorMessage(error) });
  }
});

router.post("/objects/:objectId/verify", async (req, res) => {
  try {
    res.json(await verifyObject(req.params.objectId));
  } catch (error) {
    res.status(errorMessage(error) === "Object not found" ? 404 : 400).json({ error: errorMessage(error) });
  }
});

router.get("/nodes", async (_req, res) => {
  try {
    res.json(await listNodes());
  } catch (error) {
    res.status(500).json({ error: errorMessage(error) });
  }
});

router.post("/nodes/:nodeId/fail", async (req, res) => {
  try {
    res.json(await failNode(req.params.nodeId));
  } catch (error) {
    res.status(400).json({ error: errorMessage(error) });
  }
});

router.post("/nodes/:nodeId/restore", async (req, res) => {
  try {
    res.json(await restoreNode(req.params.nodeId));
  } catch (error) {
    res.status(400).json({ error: errorMessage(error) });
  }
});

router.post("/nodes/:nodeId/corrupt", async (req, res) => {
  try {
    res.json(await corruptReplica(req.params.nodeId));
  } catch (error) {
    res.status(400).json({ error: errorMessage(error) });
  }
});

router.post("/nodes/replace", async (_req, res) => {
  try {
    res.status(201).json(await replaceNode());
  } catch (error) {
    res.status(400).json({ error: errorMessage(error) });
  }
});

router.post("/repair/:objectId", async (req, res) => {
  try {
    res.json(await repairObject(req.params.objectId));
  } catch (error) {
    res.status(errorMessage(error) === "Object not found" ? 404 : 400).json({ error: errorMessage(error) });
  }
});

router.get("/activity", async (_req, res) => {
  try {
    res.json(await listActivity());
  } catch (error) {
    res.status(500).json({ error: errorMessage(error) });
  }
});

router.get("/recovery-jobs", async (_req, res) => {
  try {
    res.json(await listRecoveryJobs());
  } catch (error) {
    res.status(500).json({ error: errorMessage(error) });
  }
});

router.get("/settings", async (_req, res) => {
  try {
    res.json(await getSettings());
  } catch (error) {
    res.status(500).json({ error: errorMessage(error) });
  }
});

router.put("/settings", async (req, res) => {
  try {
    res.json(await updateSettings(req.body ?? {}));
  } catch (error) {
    res.status(400).json({ error: errorMessage(error) });
  }
});

router.post("/reset", async (_req, res) => {
  try {
    res.json(await resetVault());
  } catch (error) {
    res.status(500).json({ error: errorMessage(error) });
  }
});

export default router;