import { createHash, randomUUID } from "node:crypto";
import { promises as fs } from "node:fs";
import path from "node:path";

export type NodeStatus = "online" | "offline" | "destroyed";
export type ReplicaStatus = "healthy" | "unavailable" | "corrupted" | "missing";
export type ObjectStatus =
  | "healthy"
  | "under-replicated"
  | "corrupted"
  | "unavailable"
  | "repairing";
export type Risk = "low" | "medium" | "critical" | "unavailable";

export type StorageNode = {
  id: string;
  name: string;
  status: NodeStatus;
  host: string;
  port: number;
  capacityBytes: number;
  usedBytes: number;
  freeBytes: number;
  objectCount: number;
  lastSeen: string;
  heartbeat: string;
  failureState: string;
};

export type Replica = {
  nodeId: string;
  path: string;
  status: ReplicaStatus;
  checksum: string;
  lastVerified: string;
};

export type VaultObject = {
  id: string;
  filename: string;
  sizeBytes: number;
  checksum: string;
  replicationFactor: number;
  status: ObjectStatus;
  createdAt: string;
  updatedAt: string;
  replicas: Replica[];
  healthyReplicas: number;
  risk: Risk;
};

export type ActivityEvent = {
  id: string;
  kind: string;
  title: string;
  detail: string;
  createdAt: string;
};

export type RecoveryJob = {
  id: string;
  objectId: string;
  status: "pending" | "running" | "completed" | "failed";
  reason: string;
  createdAt: string;
  updatedAt: string;
};

export type VaultSettings = {
  systemName: string;
  description: string;
  replicationFactor: number;
  automaticNodeReplacement: boolean;
  automaticReplicaRepair: boolean;
  checkIntervalSeconds: number;
  maxFileSizeBytes: number;
};

export type VaultState = {
  nodes: StorageNode[];
  objects: VaultObject[];
  activity: ActivityEvent[];
  recoveryJobs: RecoveryJob[];
  settings: VaultSettings;
  nextNodeNumber: number;
};

export type Dashboard = {
  files: number;
  objects: number;
  storageBytes: number;
  healthyReplicas: number;
  underReplicated: number;
  corrupted: number;
  recoveryJobs: number;
  activity: number;
  nodes: StorageNode[];
  settings: VaultSettings;
};

const storageRoot = path.resolve(process.cwd(), "storage");
const statePath = path.join(storageRoot, "vault-state.json");
const capacityBytes = 100 * 1024 * 1024 * 1024;
let mutationQueue = Promise.resolve();

const initialSettings: VaultSettings = {
  systemName: "VAULT",
  description: "Risk-Aware Distributed Object Storage",
  replicationFactor: 3,
  automaticNodeReplacement: true,
  automaticReplicaRepair: true,
  checkIntervalSeconds: 3600,
  maxFileSizeBytes: 5 * 1024 * 1024 * 1024,
};

function nodePath(nodeId: string) {
  return path.join(storageRoot, nodeId.replace(/[^a-zA-Z0-9_-]/g, ""));
}

function makeNode(number: number): StorageNode {
  const id = `node-${number}`;
  return {
    id,
    name: `Node ${number}`,
    status: "online",
    host: "127.0.0.1",
    port: 9000 + number,
    capacityBytes,
    usedBytes: 0,
    freeBytes: capacityBytes,
    objectCount: 0,
    lastSeen: new Date().toISOString(),
    heartbeat: "healthy",
    failureState: "none",
  };
}

function emptyState(): VaultState {
  return {
    nodes: [makeNode(1), makeNode(2), makeNode(3)],
    objects: [],
    activity: [],
    recoveryJobs: [],
    settings: initialSettings,
    nextNodeNumber: 4,
  };
}

async function saveState(state: VaultState) {
  await fs.mkdir(storageRoot, { recursive: true });
  const tempPath = `${statePath}.tmp`;
  await fs.writeFile(tempPath, JSON.stringify(state, null, 2), "utf8");
  await fs.rename(tempPath, statePath);
}

async function ensureState() {
  await fs.mkdir(storageRoot, { recursive: true });
  try {
    const raw = await fs.readFile(statePath, "utf8");
    const state = JSON.parse(raw) as VaultState;
    for (const node of state.nodes) await fs.mkdir(nodePath(node.id), { recursive: true });
    return state;
  } catch {
    const state = emptyState();
    for (const node of state.nodes) await fs.mkdir(nodePath(node.id), { recursive: true });
    await saveState(state);
    return state;
  }
}

async function checksum(filePath: string) {
  const buffer = await fs.readFile(filePath);
  return createHash("sha256").update(buffer).digest("hex");
}

function addActivity(state: VaultState, kind: string, title: string, detail: string) {
  state.activity.unshift({
    id: randomUUID(),
    kind,
    title,
    detail,
    createdAt: new Date().toISOString(),
  });
  state.activity = state.activity.slice(0, 100);
}

async function refreshNodeStats(state: VaultState) {
  for (const node of state.nodes) {
    const directory = nodePath(node.id);
    await fs.mkdir(directory, { recursive: true });
    const entries = await fs.readdir(directory, { withFileTypes: true });
    let usedBytes = 0;
    let objectCount = 0;
    for (const entry of entries) {
      if (!entry.isFile()) continue;
      const file = await fs.stat(path.join(directory, entry.name));
      usedBytes += file.size;
      objectCount += 1;
    }
    node.usedBytes = usedBytes;
    node.freeBytes = Math.max(0, node.capacityBytes - usedBytes);
    node.objectCount = objectCount;
    if (node.status === "online") {
      node.lastSeen = new Date().toISOString();
      node.heartbeat = "healthy";
      node.failureState = "none";
    }
  }
}

async function refreshObject(object: VaultObject, state: VaultState) {
  let healthy = 0;
  let hasCorruption = false;
  const now = new Date().toISOString();
  for (const replica of object.replicas) {
    const node = state.nodes.find((candidate) => candidate.id === replica.nodeId);
    if (!node || node.status !== "online") {
      replica.status = "unavailable";
      continue;
    }
    try {
      const actual = await checksum(replica.path);
      replica.lastVerified = now;
      replica.checksum = actual;
      if (actual === object.checksum) {
        replica.status = "healthy";
        healthy += 1;
      } else {
        replica.status = "corrupted";
        hasCorruption = true;
      }
    } catch {
      replica.status = "missing";
    }
  }
  object.healthyReplicas = healthy;
  if (hasCorruption) object.status = "corrupted";
  else if (healthy >= object.replicationFactor) object.status = "healthy";
  else if (healthy === 0) object.status = "unavailable";
  else object.status = "under-replicated";
  object.risk =
    healthy >= object.replicationFactor
      ? "low"
      : healthy === object.replicationFactor - 1
        ? "medium"
        : healthy > 0
          ? "critical"
          : "unavailable";
  object.updatedAt = now;
}

async function refreshState(state: VaultState) {
  await refreshNodeStats(state);
  for (const object of state.objects) await refreshObject(object, state);
  await refreshNodeStats(state);
}

async function mutate<T>(operation: (state: VaultState) => Promise<T>) {
  const next = mutationQueue.then(async () => {
    const state = await ensureState();
    const result = await operation(state);
    await refreshState(state);
    await saveState(state);
    return result;
  });
  mutationQueue = next.then(() => undefined, () => undefined);
  return next;
}

export async function readState() {
  const state = await ensureState();
  await refreshState(state);
  await saveState(state);
  return state;
}

export async function getDashboard(): Promise<Dashboard> {
  const state = await readState();
  return {
    files: state.objects.length,
    objects: state.objects.length,
    storageBytes: state.objects.reduce((sum, object) => sum + object.sizeBytes, 0),
    healthyReplicas: state.objects.reduce((sum, object) => sum + object.healthyReplicas, 0),
    underReplicated: state.objects.filter((object) => object.status === "under-replicated").length,
    corrupted: state.objects.filter((object) => object.status === "corrupted").length,
    recoveryJobs: state.recoveryJobs.filter((job) => job.status === "pending" || job.status === "running").length,
    activity: state.activity.length,
    nodes: state.nodes,
    settings: state.settings,
  };
}

export async function listObjects() {
  const state = await readState();
  return state.objects;
}

export async function listNodes() {
  const state = await readState();
  return state.nodes;
}

export async function listActivity() {
  const state = await readState();
  return state.activity;
}

export async function listRecoveryJobs() {
  const state = await readState();
  return state.recoveryJobs;
}

export async function getSettings() {
  const state = await readState();
  return state.settings;
}

export async function uploadObject(filename: string, buffer: Buffer) {
  return mutate(async (state) => {
    if (!filename || buffer.length === 0) throw new Error("A non-empty file is required");
    if (buffer.length > state.settings.maxFileSizeBytes) throw new Error("File exceeds the configured maximum size");
    const healthyNodes = state.nodes.filter((node) => node.status === "online");
    if (healthyNodes.length < state.settings.replicationFactor) {
      throw new Error(`At least ${state.settings.replicationFactor} healthy nodes are required`);
    }
    const objectId = `obj-${randomUUID()}`;
    const safeFilename = path.basename(filename).replace(/[^\w.\- ]/g, "_").slice(0, 180) || "unnamed-file";
    const objectChecksum = createHash("sha256").update(buffer).digest("hex");
    const createdAt = new Date().toISOString();
    const replicas: Replica[] = [];
    for (const node of healthyNodes.slice(0, state.settings.replicationFactor)) {
      const replicaPath = path.join(nodePath(node.id), objectId);
      await fs.writeFile(replicaPath, buffer, { flag: "wx" });
      const verifiedChecksum = await checksum(replicaPath);
      if (verifiedChecksum !== objectChecksum) throw new Error(`Replica verification failed on ${node.name}`);
      replicas.push({
        nodeId: node.id,
        path: replicaPath,
        status: "healthy",
        checksum: verifiedChecksum,
        lastVerified: createdAt,
      });
      addActivity(state, "replica", "Replica created", `${safeFilename} written to ${node.name}`);
    }
    const object: VaultObject = {
      id: objectId,
      filename: safeFilename,
      sizeBytes: buffer.length,
      checksum: objectChecksum,
      replicationFactor: state.settings.replicationFactor,
      status: "healthy",
      createdAt,
      updatedAt: createdAt,
      replicas,
      healthyReplicas: replicas.length,
      risk: "low",
    };
    state.objects.unshift(object);
    addActivity(state, "upload", "Object uploaded", `${safeFilename} · ${replicas.length} verified replicas`);
    return object;
  });
}

export async function deleteObject(objectId: string) {
  return mutate(async (state) => {
    const index = state.objects.findIndex((object) => object.id === objectId);
    if (index < 0) throw new Error("Object not found");
    const [object] = state.objects.splice(index, 1);
    for (const replica of object.replicas) {
      try {
        await fs.rm(replica.path, { force: true });
      } catch {
        // The object is already removed from metadata; a missing replica is safe to ignore.
      }
    }
    addActivity(state, "delete", "Object deleted", `${object.filename} and its replicas removed`);
  });
}

export async function verifyObject(objectId: string) {
  return mutate(async (state) => {
    const object = state.objects.find((candidate) => candidate.id === objectId);
    if (!object) throw new Error("Object not found");
    await refreshObject(object, state);
    addActivity(state, object.status === "healthy" ? "verify" : "warning", "Integrity check completed", `${object.filename} · ${object.healthyReplicas}/${object.replicationFactor} healthy replicas`);
    return object;
  });
}

export async function failNode(nodeId: string) {
  const failedNode = await mutate(async (state) => {
    const node = state.nodes.find((candidate) => candidate.id === nodeId);
    if (!node) throw new Error("Node not found");
    if (node.status !== "online") return node;
    node.status = "offline";
    node.heartbeat = "connection lost";
    node.failureState = "failure detected";
    addActivity(state, "node", "Node failure detected", `${node.name} is unavailable; replica health recalculated`);
    for (const object of state.objects) {
      await refreshObject(object, state);
      if (object.status !== "healthy") {
        const existing = state.recoveryJobs.find((job) => job.objectId === object.id && (job.status === "pending" || job.status === "running"));
        if (!existing) {
          state.recoveryJobs.push({
            id: randomUUID(),
            objectId: object.id,
            status: "pending",
            reason: `${object.healthyReplicas}/${object.replicationFactor} healthy replicas remain`,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          });
        }
      }
    }
    return node;
  });
  const state = await readState();
  if (state.settings.automaticNodeReplacement) {
    await replaceNode();
  }
  if (state.settings.automaticReplicaRepair) {
    const pendingObjects = (await listObjects()).filter((object) => object.status !== "healthy");
    for (const object of pendingObjects) {
      try {
        await repairObject(object.id);
      } catch {
        // Keep the recovery job pending when no safe source or target exists.
      }
    }
  }
  return failedNode;
}

export async function restoreNode(nodeId: string) {
  return mutate(async (state) => {
    const node = state.nodes.find((candidate) => candidate.id === nodeId);
    if (!node) throw new Error("Node not found");
    if (node.status === "destroyed") throw new Error("Destroyed nodes cannot be restored");
    node.status = "online";
    node.heartbeat = "healthy";
    node.failureState = "none";
    node.lastSeen = new Date().toISOString();
    addActivity(state, "node", "Node restored", `${node.name} is accepting health checks again`);
    return node;
  });
}

export async function corruptReplica(nodeId: string) {
  return mutate(async (state) => {
    const node = state.nodes.find((candidate) => candidate.id === nodeId);
    if (!node) throw new Error("Node not found");
    const object = state.objects.find((candidate) => candidate.replicas.some((replica) => replica.nodeId === nodeId && replica.status === "healthy"));
    if (!object) throw new Error("No healthy replica found on this node");
    const replica = object.replicas.find((candidate) => candidate.nodeId === nodeId)!;
    await fs.appendFile(replica.path, Buffer.from("\nVAULT_CORRUPTION_TEST\n"));
    await refreshObject(object, state);
    addActivity(state, "warning", "Replica corruption detected", `${object.filename} on ${node.name} no longer matches SHA-256`);
    return object;
  });
}

export async function replaceNode() {
  return mutate(async (state) => {
    const number = state.nextNodeNumber;
    state.nextNodeNumber += 1;
    const node = makeNode(number);
    await fs.mkdir(nodePath(node.id), { recursive: true });
    state.nodes.push(node);
    addActivity(state, "node", "Replacement node created", `${node.name} joined the cluster on port ${node.port}`);
    return node;
  });
}

export async function repairObject(objectId: string) {
  return mutate(async (state) => {
    const object = state.objects.find((candidate) => candidate.id === objectId);
    if (!object) throw new Error("Object not found");
    object.status = "repairing";
    const job = state.recoveryJobs.find((candidate) => candidate.objectId === objectId && (candidate.status === "pending" || candidate.status === "running"));
    if (job) {
      job.status = "running";
      job.updatedAt = new Date().toISOString();
    }
    await refreshObject(object, state);
    const source = object.replicas.find((replica) => replica.status === "healthy");
    if (!source) throw new Error("No healthy source replica is available");
    const sourceBytes = await fs.readFile(source.path);
    const healthyIds = new Set(object.replicas.filter((replica) => replica.status === "healthy").map((replica) => replica.nodeId));
    const targets = state.nodes.filter((node) => node.status === "online" && !healthyIds.has(node.id));
    for (const target of targets) {
      if (object.healthyReplicas >= object.replicationFactor) break;
      const existing = object.replicas.find((replica) => replica.nodeId === target.id);
      const destination = existing?.path ?? path.join(nodePath(target.id), object.id);
      await fs.writeFile(destination, sourceBytes);
      const verifiedChecksum = await checksum(destination);
      if (verifiedChecksum !== object.checksum) throw new Error(`Repair verification failed on ${target.name}`);
      if (existing) {
        existing.path = destination;
        existing.status = "healthy";
        existing.checksum = verifiedChecksum;
        existing.lastVerified = new Date().toISOString();
      } else {
        object.replicas.push({
          nodeId: target.id,
          path: destination,
          status: "healthy",
          checksum: verifiedChecksum,
          lastVerified: new Date().toISOString(),
        });
      }
      await refreshObject(object, state);
      addActivity(state, "repair", "Replica repaired", `${object.filename} copied and verified on ${target.name}`);
    }
    await refreshObject(object, state);
    const repairSucceeded = object.healthyReplicas >= object.replicationFactor
      && object.replicas.filter((replica) => replica.status === "healthy").length >= object.replicationFactor;
    if (job) {
      job.status = repairSucceeded ? "completed" : "failed";
      job.updatedAt = new Date().toISOString();
    }
    addActivity(state, repairSucceeded ? "repair" : "warning", "Repair job completed", `${object.filename} · ${object.healthyReplicas}/${object.replicationFactor} healthy replicas`);
    return object;
  });
}

export async function downloadObject(objectId: string) {
  const state = await readState();
  const object = state.objects.find((candidate) => candidate.id === objectId);
  if (!object) throw new Error("Object not found");
  const source = object.replicas.find((replica) => replica.status === "healthy");
  if (!source) throw new Error("Object has no healthy replica");
  const bytes = await fs.readFile(source.path);
  addActivity(state, "download", "Object downloaded", `${object.filename} served from ${source.nodeId}`);
  await saveState(state);
  return { object, bytes };
}

export async function updateSettings(update: Partial<VaultSettings>) {
  return mutate(async (state) => {
    state.settings = {
      ...state.settings,
      ...update,
      replicationFactor: Math.max(1, Math.min(5, Number(update.replicationFactor ?? state.settings.replicationFactor))),
      checkIntervalSeconds: Math.max(10, Number(update.checkIntervalSeconds ?? state.settings.checkIntervalSeconds)),
      maxFileSizeBytes: Math.max(1, Number(update.maxFileSizeBytes ?? state.settings.maxFileSizeBytes)),
    };
    addActivity(state, "settings", "Settings updated", "Persistent Vault settings saved");
    return state.settings;
  });
}

export async function resetVault() {
  return mutate(async (state) => {
    for (const node of state.nodes) {
      await fs.rm(nodePath(node.id), { recursive: true, force: true });
    }
    const fresh = emptyState();
    for (const node of fresh.nodes) await fs.mkdir(nodePath(node.id), { recursive: true });
    Object.assign(state, fresh);
    return getDashboardFromState(state);
  });
}

function getDashboardFromState(state: VaultState): Dashboard {
  return {
    files: state.objects.length,
    objects: state.objects.length,
    storageBytes: state.objects.reduce((sum, object) => sum + object.sizeBytes, 0),
    healthyReplicas: state.objects.reduce((sum, object) => sum + object.healthyReplicas, 0),
    underReplicated: state.objects.filter((object) => object.status === "under-replicated").length,
    corrupted: state.objects.filter((object) => object.status === "corrupted").length,
    recoveryJobs: state.recoveryJobs.filter((job) => job.status === "pending" || job.status === "running").length,
    activity: state.activity.length,
    nodes: state.nodes,
    settings: state.settings,
  };
}